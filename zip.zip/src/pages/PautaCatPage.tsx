// src/pages/PautaCatPage.tsx
import React, { useEffect, useMemo, useRef, useState } from "react";
import toast from "react-hot-toast";

import {
  salvarPautaNoFirestoreAuto,
  regravarPautaPorHash,
  hashDoArquivo,
  listarPautas,
  carregarPautaCompleta,
} from "../services/pautaService";

import { getNcmSetCgim } from "../services/ncmsService";

import {
  carregarAtribuicoesPorChaves,
  salvarAtribuicaoPleito,
} from "../services/atribuicoesService";

import { useNavigate } from "react-router-dom";

type Secao = {
  titulo: string;
  headers: string[];
  rows: Array<Record<string, string>>;
  qtd?: number;
};

type PautaResumo = {
  id: string;
  fileName: string;
  meeting?: string;
  createdAt?: any;
  stats?: {
    secoes?: number | number[];
    tabelas?: number | number[];
    itens?: number | number[];
  } | null;
};

type PautaCompleta = {
  id: string;
  meeting?: string;
  secoes: Secao[];
  stats?: any;
};

type DiffResumo = {
  novos: number;
  alterados: number;
  removidos: number;
  mantidos: number;
} | null;

const RESPONSAVEIS = [
  "—",
  "Pedro Reckziegel",
  "Henrique de Barros",
  "Gustavo Bliacheris",
  "Larissa Ayres",
  "Ricardo Zomer",
  "Marcelo Rocha",
  "Bruna Carvalho",
  "André Cruz",
  "Paula Sandri",
  "Carlos M. P.",
  "Renato Salles",
  "Cláudia Nunes",
  "João Brochado",
  "Maria Eduarda",
  "Helena Prado",
  "Fernanda Ribeiro",
  "Luiz Felipe",
  "Mariana Dias",
  "Rafael Azevedo",
  "Camila Santos",
  "Victor Lima",
  "Isabella Tavares",
  "Rodrigo Lopes",
  "Ana Paula",
  "Bruno Silva",
  "Daniela Castro",
  "Eduardo Teixeira",
  "Felipe M.",
  "Gabriela Couto",
  "Hugo Carvalho",
  "Igor P.",
  "Júlia Almeida",
  "Karen R.",
  "Leonardo C.",
  "Mateus A.",
  "Natália B.",
  "Otávio F.",
  "Patrícia G.",
  "Queiroz",
  "Roberta L.",
  "Sérgio H.",
  "Talita K.",
  "Ubirajara",
  "Vinícius",
  "Wagner",
  "Xavier",
  "Yasmin",
  "Zuleika",
  "Carlos Henrique",
  "Gustavo Silva",
  "Antônio Azambuja",
  "Tólio Ribeiro",
] as const;

// ---------------- helpers ----------------
const norm = (s: string) =>
  (s || "").replace(/\u00A0/g, " ").replace(/\s+/g, " ").trim();

const normKey = (s: string) =>
  norm(s).toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");

function onlyDigits(s: string | undefined | null): string {
  if (!s) return "";
  return String(s).replace(/\D+/g, "");
}

function isHeaderRelevant(h: string) {
  const k = normKey(h);
  return (
    k.includes("ncm") ||
    k.includes("produto") ||
    k.includes("pleiteante") ||
    k.includes("quota") ||
    k.includes("redu") || // redução
    k === "ex" ||
    k.includes("pais") ||
    k.includes("situa") ||
    k.includes("tipo de pleito") ||
    k.includes("aliquota") ||
    k.includes("processo") ||
    k.includes("prazo")
  );
}

function dedupeHeaders(headers: string[]) {
  const seen = new Map<string, number>();
  return headers.map((h) => {
    const base = norm(h);
    const k = normKey(base);
    const count = (seen.get(k) || 0) + 1;
    seen.set(k, count);
    return count === 1 ? base : `${base} ${count}`;
  });
}

function decodeHtmlBest(buf: ArrayBuffer): string {
  const utf = new TextDecoder("utf-8", { fatal: false }).decode(buf);
  const iso = new TextDecoder("iso-8859-1").decode(buf);

  const score = (s: string) => {
    const bad = (s.match(/Ã.|Â.|�/g) || []).length;
    // penaliza quando há “caracteres estranhos”
    return -bad;
  };
  return score(utf) >= score(iso) ? utf : iso;
}

function extrairMeeting(html: string): string | undefined {
  try {
    const h1 = html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i)?.[1] || "";
    const plain = h1
      .replace(/<[^>]+>/g, " ")
      .replace(/\s+/g, " ")
      .trim();
    return plain || undefined;
  } catch {
    return undefined;
  }
}

// --- parse mínimo p/ pauta HTML (seções -> headers/rows) ---
function parsePautaHtml(html: string): { secoes: Secao[]; stats: any } {
  // super simplificado: faz split por <h2> de seção
  const secs: Secao[] = [];
  const regexH2 = /<h2[^>]*>([\s\S]*?)<\/h2>/gi;
  let m: RegExpExecArray | null;
  const indices: number[] = [];
  const titles: string[] = [];
  while ((m = regexH2.exec(html))) {
    indices.push(m.index);
    titles.push(m[1].replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim());
  }
  indices.push(html.length);

  for (let i = 0; i < titles.length; i++) {
    const from = indices[i];
    const to = indices[i + 1];
    const chunk = html.slice(from, to);

    // linhas de tabela: uma heurística simples por <tr> e <td>/<th>
    const trs = Array.from(chunk.matchAll(/<tr[^>]*>([\s\S]*?)<\/tr>/gi)).map(
      (x) => x[1]
    );
    if (!trs.length) continue;

    const rawRows = trs.map((tr) =>
      Array.from(tr.matchAll(/<(?:td|th)[^>]*>([\s\S]*?)<\/(?:td|th)>/gi)).map(
        (x) =>
          x[1]
            .replace(/<br\s*\/?>/gi, "\n")
            .replace(/<[^>]+>/g, " ")
            .replace(/\s+/g, " ")
            .trim()
      )
    );

    // primeira linha como header
    const headers = dedupeHeaders(
      (rawRows[0] || []).filter((h) => isHeaderRelevant(h))
    );
    const body = rawRows.slice(1).map((row) => {
      const obj: Record<string, string> = {};
      headers.forEach((h, i) => (obj[h] = String(row[i] || "")));
      return obj;
    });

    secs.push({
      titulo: titles[i],
      headers,
      rows: body,
    });
  }

  return {
    secoes: secs,
    stats: {
      secoes: secs.length,
      tabelas: secs.reduce((a, s) => a + (s.rows.length ? 1 : 0), 0),
      itens: secs.reduce((a, s) => a + s.rows.length, 0),
    },
  };
}

// ---------------- componente ----------------
const PautaCatPage: React.FC = () => {
  const [secoes, setSecoes] = useState<Secao[]>([]);
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [somenteCgim, setSomenteCgim] = useState(true);
  const [ncmSet, setNcmSet] = useState<Set<string>>(new Set());
  const [ultimoHash, setUltimoHash] = useState<string | null>(null);
  const [historico, setHistorico] = useState<PautaResumo[]>([]);
  const [currentPautaId, setCurrentPautaId] = useState<string | null>(null);
  const [pautaBaseId, setPautaBaseId] = useState<string>(""); // para diffs
  const [diffResumo, setDiffResumo] = useState<DiffResumo>(null);

  const inputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();

  useEffect(() => {
    (async () => {
      try {
        const set = await getNcmSetCgim();
        setNcmSet(set);
      } catch {}
    })();
  }, []);

  // carregar histórico basico
  useEffect(() => {
    (async () => {
      try {
        const list = await listarPautas(5);
        setHistorico(list);
      } catch {}
    })();
  }, []);

  const abrirFileDialog = () => inputRef.current?.click();

  async function onFile(file: File) {
    try {
      setLoading(true);
      const buf = await file.arrayBuffer();
      const html = decodeHtmlBest(buf);
      const meeting = extrairMeeting(html);
      const { secoes, stats } = parsePautaHtml(html);
      setSecoes(secoes);
      setStats(stats);

      const fileHash = await hashDoArquivo(buf);
      const pautaId = await (salvarPautaNoFirestoreAuto as any)(
        file.name,
        fileHash,
        secoes,
        stats,
        meeting
      );

      if (pautaId) {
        setCurrentPautaId(pautaId);

        // se tiver pauta base, tenta gerar diff
        try {
          if (pautaBaseId && pautaBaseId !== pautaId) {
            const resumo = await diffPautas(pautaBaseId, pautaId, { aplicarMarcacoes: true });
            if (resumo?.contagens) {
              setDiffResumo(resumo.contagens);
              toast.success(
                `Diferenças aplicadas: ${resumo.contagens.removidos} removidos, ${resumo.contagens.alterados} alterados, ${resumo.contagens.novos} novos.`
              );
            }
          } else {
            setDiffResumo(null);
          }
        } catch (e) {
          console.error(e);
          toast.error("Falha ao comparar pautas (diff).");
        }
      } else {
        setCurrentPautaId(null);
      }

      setUltimoHash(fileHash);
      toast.success("Arquivo analisado com sucesso.");
    } catch (e: any) {
      console.error(e);
      toast.error("Falha ao processar arquivo.");
    } finally {
      setLoading(false);
    }
  }

  // All headers presentes em todas as seções
  const allHeaders = useMemo(() => {
    const set = new Set<string>();
    for (const s of secoes) {
      for (const h of s.headers) set.add(h);
    }
    return Array.from(set);
  }, [secoes]);

  const ncmHeaderName = useMemo(() => {
    const match = allHeaders.find((h) => normKey(h).startsWith("ncm"));
    return match || "NCM";
  }, [allHeaders]);

  const produtoHeaderName = useMemo(() => {
    const match = allHeaders.find((h) => normKey(h).startsWith("produto"));
    return match || "Produto";
  }, [allHeaders]);

  const pleiteanteHeaderName = useMemo(() => {
    const match = allHeaders.find((h) => normKey(h).includes("pleiteante"));
    return match || "Pleiteante";
  }, [allHeaders]);

  // aplicar filtro CGIM (mantém só NCMs da CGIM)
  const secoesFiltradas = useMemo(() => {
    if (!somenteCgim) return secoes;
    const fil = secoes.map((sec) => {
      const rows = sec.rows.filter((r) => {
        const ncm = onlyDigits(String(r[ncmHeaderName] || ""));
        return ncm && ncmSet.has(ncm);
      });
      return { ...sec, rows, qtd: rows.length };
    });
    return fil.filter((s) => s.qtd > 0);
  }, [secoes, somenteCgim, ncmSet, ncmHeaderName]);

  // Carregar atribuições sempre que as seções mudarem
  useEffect(() => {
    (async () => {
      const keys: string[] = [];
      for (const s of secoes) {
        for (const r of s.rows) {
          // montamos um objeto normalizado com as chaves esperadas pelo service
          const rowForKey = {
            NCM: onlyDigits(String(r[ncmHeaderName] || "")),
            Produto: String(r[produtoHeaderName] || ""),
            Pleiteante: String(r[pleiteanteHeaderName] || ""),
          } as Record<string, string>;
          keys.push(gerarPleitoKey(rowForKey));
        }
      }
      if (!keys.length) {
        setAtribs({});
        return;
      }
      try {
        const map = await carregarAtribuicoesPorChaves(keys);
        setAtribs(map);
      } catch {
        setAtribs({});
      }
    })();
  }, [secoes, ncmHeaderName, produtoHeaderName, pleiteanteHeaderName]);

  const [atribs, setAtribs] = useState<Record<string, string>>({});

  // salvar atribuição de responsável
  const salvarResp = async (
    row: Record<string, string>,
    tituloSecao: string,
    novoResp: string
  ) => {
    // mesma normalização usada acima
    const rowForKey = {
      NCM: onlyDigits(String(row[ncmHeaderName] || "")),
      Produto: String(row[produtoHeaderName] || ""),
      Pleiteante: String(row[pleiteanteHeaderName] || ""),
    } as Record<string, string>;

    const key = gerarPleitoKey(rowForKey);

    try {
      await salvarAtribuicaoPleito({
        pleitoKey: key,
        responsavelNome: novoResp || "—", // "—" apaga
        ncm: rowForKey.NCM,
        produto: rowForKey.Produto,
        pleiteante: rowForKey.Pleiteante,
        pautaId: currentPautaId || undefined,
        tituloSecao,
      });

      setAtribs((m) => ({ ...m, [key]: novoResp === "—" ? "" : novoResp }));
      toast.success(novoResp && novoResp !== "—" ? `Atribuído a ${novoResp}` : "Atribuição removida.");
    } catch (e) {
      console.error(e);
      toast.error("Falha ao salvar atribuição.");
    }
  };

  // ---- helpers p/ Histórico: normalizar contadores vindos como número ou array ----
  const asNum = (v: number | number[] | undefined, fallback = 0) => {
    if (Array.isArray(v)) return v.length;
    if (typeof v === "number" && Number.isFinite(v)) return v;
    return fallback;
  };

  // ---- botão “Regravar” por hash, para atualizar meeting/contagens e “fixar” pauta existente ----
  const regravar = async (hash: string) => {
    try {
      setLoading(true);
      await regravarPautaPorHash(hash);
      toast.success("Pauta regravada.");
      // recarrega histórico
      const list = await listarPautas(5);
      setHistorico(list);
    } catch (e) {
      console.error(e);
      toast.error("Falha ao regravar pauta.");
    } finally {
      setLoading(false);
    }
  };

  // ---- abrir pauta do histórico (carregar do firestore) ----
  const abrirPautaDoHistorico = async (id: string) => {
    try {
      setLoading(true);
      const doc = await carregarPautaCompleta(id);
      setCurrentPautaId(doc.id);
      setSecoes(doc.secoes || []);
      setStats(doc.stats || null);
      setDiffResumo(null);
      toast.success("Pauta carregada.");
    } catch (e) {
      console.error(e);
      toast.error("Falha ao carregar pauta.");
    } finally {
      setLoading(false);
    }
  };

  // contagens exibidas ao lado do upload
  const h0 = useMemo(() => {
    const asNum = (v: any, fallback = 0) => {
      if (Array.isArray(v)) return v.length;
      if (typeof v === "number" && Number.isFinite(v)) return v;
      return fallback;
    };
    return {
      secoes: asNum(h0.secoes),
      tabelas: asNum(h0.tabelas),
      itens: asNum(h0.itens),
    };
  })();

  return (
    <div className="p-6">
      <h1 className="text-xl font-bold mb-4">Pauta CAT</h1>

      {/* Upload */}
      <div className="mb-6 p-4 bg-white rounded border">
        <div className="flex flex-wrap items-center gap-3">
          <span>Importe o arquivo da pauta em <b>.html</b> (exportado do SEI).</span>
        </div>

        <div className="mt-3 flex flex-wrap items-center gap-3">
          <span className="text-sm text-gray-600">
            Pauta base (ID):
          </span>
          <input
            className="border rounded px-2 py-1"
            placeholder="ID da pauta original (ex.: abc123)"
            value={pautaBaseId}
            onChange={(e) => setPautaBaseId(e.target.value)}
            style={{ minWidth: 260 }}
          />
          {diffResumo && (
            <span className="px-2 py-1 text-xs rounded bg-blue-50 text-blue-800 border border-blue-200">
              Δ {diffResumo.novos} novos · {diffResumo.alterados} alterados · {diffResumo.removidos} removidos · {diffResumo.mantidos} mantidos
            </span>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <input
            ref={inputRef}
            type="file"
            className="hidden"
            accept=".html,.htm"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) onFile(f);
              e.currentTarget.value = "";
            }}
          />
          <button
            onClick={abrirFileDialog}
            className="inline-flex items-center px-3 py-2 bg-gray-100 hover:bg-gray-200 rounded"
          >
            Escolher Arquivo
          </button>

          {ultimoHash && (
            <button
              onClick={() => regravar(ultimoHash)}
              className="inline-flex items-center px-3 py-2 bg-white border rounded hover:bg-gray-50"
              title="Regravar a pauta mais recente (atualiza meeting/contagens)."
            >
              Regravar
            </button>
          )}

          {stats && (
            <div className="text-sm text-gray-600">
              Seções detectadas: <b>{h0.secoes}</b> | Tabelas consideradas: <b>{h0.tabelas}</b> | Pleitos extraídos: <b>{h0.itens}</b>
              {somenteCgim ? (
                <>
                  &nbsp;&nbsp;|&nbsp;&nbsp; <b>Filtro CGIM</b> ativo
                </>
              ) : null}
            </div>
          )}
        </div>
      </div>

      {/* Histórico */}
      <div className="mb-6 p-4 bg-white rounded border">
        <div className="flex items-center justify-between mb-2">
          <h2 className="font-semibold">Histórico (últimas 5 pautas)</h2>
          <button
            type="button"
            onClick={() => navigate("/historico")}
            className="text-sm text-blue-600 hover:underline"
          >
            ver tudo
          </button>
        </div>

        {historico.length === 0 ? (
          <div className="text-sm text-gray-500">Nenhum item de histórico.</div>
        ) : (
          <div className="space-y-2">
            {historico.map((h) => (
              <div
                key={h.id}
                className="border rounded p-3 flex items-center justify-between bg-white"
              >
                <div className="min-w-0">
                  <div className="font-medium truncate">
                    {h.meeting || "(sem título)"}
                  </div>
                  <div className="text-xs text-gray-500">
                    {h.fileName}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-gray-600">
                    {asNum(h.stats?.secoes)} seções · {asNum(h.stats?.tabelas)} tabelas · {asNum(h.stats?.itens)} itens
                  </span>
                  <button
                    onClick={() => abrirPautaDoHistorico(h.id)}
                    className="px-3 py-1 rounded bg-gray-100 hover:bg-gray-200"
                  >
                    abrir
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Render das seções (com filtro CGIM aplicado) */}
      {secoesFiltradas.map((sec, idxSec) => {
        const headers = [...sec.headers, "Responsável"];
        return (
          <div key={`${sec.titulo}-${idxSec}`} className="mb-8 bg-white border rounded">
            <div className="px-4 py-3 border-b font-semibold flex items-center justify-between">
              <span>{String(sec.titulo)}</span>
              <span className="text-sm text-gray-500">{Number(sec.qtd) || 0} pleitos</span>
            </div>

            <div className="overflow-x-auto">
              <table className="min-w-full table-fixed">
                <thead>
                  <tr className="bg-gray-100">
                    {headers.map((h) => (
                      <th
                        key={h}
                        className="px-4 py-2 text-left align-top text-sm md:text-base break-words"
                      >
                        {String(h)}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {sec.rows.map((row, rIdx) => {
                    // valor atual
                    const rowForKey = {
                      NCM: onlyDigits(String(row[ncmHeaderName] || "")),
                      Produto: String(row[produtoHeaderName] || ""),
                      Pleiteante: String(row[pleiteanteHeaderName] || ""),
                    } as Record<string, string>;

                    const key = gerarPleitoKey(rowForKey);
                    const atual = atribs[key] || "";

                    return (
                      <tr key={`r-${rIdx}`} className="even:bg-gray-50">
                        {sec.headers.map((h) => {
                          const cell = String(row[h] ?? "");
                          const isNcm = normKey(h).startsWith("ncm");
                          return (
                            <td
                              key={`${h}-${rIdx}`}
                              className={`px-4 py-3 align-top whitespace-pre-wrap ${ (normKey(h).startsWith("ncm") || normKey(h).startsWith("produto") || normKey(h).includes("pleiteante") ) ? "break-all" : "break-words" } text-sm md:text-base`}
                            >
                              {isNcm ? <b>{cell}</b> : cell}
                            </td>
                          );
                        })}

                        {/* Responsável */}
                        <td className="px-4 py-3 align-top">
                          <select
                            className="border rounded px-2 py-1 text-sm"
                            value={atual || "—"}
                            onChange={(e) => salvarResp(row, sec.titulo, e.target.value)}
                          >
                            {RESPONSAVEIS.map((n) => (
                              <option key={n} value={n}>
                                {n}
                              </option>
                            ))}
                          </select>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default PautaCatPage;

// ========= helpers de chave =========
function gerarPleitoKey(row: Record<string, string>): string {
  const n8 = onlyDigits(row.NCM || "").slice(0, 8);
  const p = norm(row.Produto || "");
  const c = norm(row.Pleiteante || "");
  return [n8, p, c].filter(Boolean).join("|");
}

// ========= diff entre pautas =========
async function diffPautas(
  pautaBaseId: string,
  pautaId: string,
  opts?: { aplicarMarcacoes?: boolean }
) {
  try {
    const docBase = await carregarPautaCompleta(pautaBaseId);
    const docNova = await carregarPautaCompleta(pautaId);

    const secoesBase = docBase?.secoes || [];
    const secoesNova = docNova?.secoes || [];

    // índice rápido por chave
    const idxBase = new Map<string, Record<string, string>>();
    for (const s of secoesBase) {
      for (const r of s.rows) {
        const key = gerarPleitoKey({
          NCM: onlyDigits(String(r["NCM"] || "")),
          Produto: String(r["Produto"] || ""),
          Pleiteante: String(r["Pleiteante"] || ""),
        } as any);
        idxBase.set(key, r);
      }
    }

    let novos = 0,
      alterados = 0,
      mantidos = 0,
      removidos = 0;

    // percorre nova
    for (const s of secoesNova) {
      for (const r of s.rows) {
        const key = gerarPleitoKey({
          NCM: onlyDigits(String(r["NCM"] || "")),
          Produto: String(r["Produto"] || ""),
          Pleiteante: String(r["Pleiteante"] || ""),
        } as any);
        const antigo = idxBase.get(key);
        if (!antigo) {
          novos += 1;
        } else {
          // compara alguns campos principais
          const campos = ["NCM", "Produto", "Pleiteante"];
          const mudou = campos.some((c) => String(antigo[c] || "") !== String(r[c] || ""));
          if (mudou) alterados += 1;
          else mantidos += 1;
          idxBase.delete(key);
        }
      }
    }

    removidos = idxBase.size;

    if (opts?.aplicarMarcacoes) {
      // nada visual a aplicar aqui (essa página não colore linhas),
      // só retornamos as contagens para exibição.
    }

    return { contagens: { novos, alterados, removidos, mantidos } };
  } catch (e) {
    console.error(e);
    return null;
  }
}
