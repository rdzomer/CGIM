// src/firebase.ts
import { initializeApp, getApps } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";

// Configuração fixa para teste — sem .env
const firebaseConfig = {
  apiKey: "AIzaSyBrnZhQYQbdFMDZTlfukSIjoY2m3akJ4Wc",
  authDomain: "catcgim.firebaseapp.com",
  projectId: "catcgim",
  storageBucket: "catcgim.appspot.com",
  messagingSenderId: "503717887651",
  appId: "1:503717887651:web:876b4423a7d65fc6d28916"
};

if (import.meta.env.DEV) {
  console.info("[Firebase] usando key prefix:", firebaseConfig.apiKey.slice(0, 6));
  console.info("[Firebase] domain/project:", firebaseConfig.authDomain, firebaseConfig.projectId);
}

// Inicializa app Firebase se ainda não estiver inicializado
const app = getApps().length ? getApps()[0] : initializeApp(firebaseConfig);

// Exporta instâncias do Firestore e Auth
export const db = getFirestore(app);
export const auth = getAuth(app);
